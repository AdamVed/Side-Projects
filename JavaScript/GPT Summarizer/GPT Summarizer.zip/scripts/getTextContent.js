// getTextContent.js
console.log("In getTextContent");

// Clone the current document to not alter the page's actual DOM
var documentClone = document.cloneNode(true);

// Create a Readability object with the cloned document
var readability = new Readability(documentClone);
var article = readability.parse();

// Send the extracted content back to the background script
browser.runtime.sendMessage({
    type: 'extractedContent',
    content: article.textContent
});
