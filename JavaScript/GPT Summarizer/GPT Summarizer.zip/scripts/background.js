// background.js

var count = 0;

browser.commands.onCommand.addListener((command) => {
  if (command === "toggle-popup") {
    browser.browserAction.openPopup(); // Toggle the popup
  }
});

browser.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.type === "getTextContent") {
    browser.tabs.query(
      {
        active: true,
        currentWindow: true,
      },
      function (tabs) {
        var activeTab = tabs[0];
        browser.tabs.executeScript(activeTab.id, {
          file: "scripts/getTextContent.js",
        });
      }
    );
  }
});

browser.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.type === "extractedContent" && message.content) {
    callPerplexityAPI(message.content, true);
  }
});

async function callPerplexityAPI(content, is4KContext) {
  const API_KEY = "YOUR_API_KEY_HERE";
  const API_ENDPOINT = "https://api.openai.com/v1/chat/completions";
  const MODEL = "gpt-3.5-turbo"
  //const MODEL = "gpt-4-turbo-preview"
	
  
  let options = {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${API_KEY}`,
    },
    timeout: 60000, // Set the timeout to 60 seconds
    body: JSON.stringify({
      model: MODEL,
      messages: [
        {
          role: "system",
          content:
            'Summarize content accurately and precisely. Provide an informative deep overview. DO NOT INCLUDE META DATA LIKE: name of the author, sources, etc. Stylizing: return bolded parts like so "**<bolded content>**", return h4 headers like so "-<h4 header content>:", return italics like so "_<italics content>_", return h3 content like so "==<h3 header content>==". Use those stylings whenever appropriate to make your summary include headers, subheaders, etc. Make it visually clean and pleasing to read.',
        },
        {
          role: "user",
          content: content,
        },
      ],
    }),
  };

  var response = await fetch(API_ENDPOINT, options);
  await handleResponse(content, is4KContext, response);
}

async function handleResponse(content, is4KContext, response) {
  if (response.status === 400 && is4KContext) {
    console.error("Error 400: Bad request, retrying with is4KContext = false");
    await callPerplexityAPI(content, false);
    return;
  }

  var data = await response.json(); // Await the response.json() promise

  console.log("Data: ", data);

  console.log("Finalizing");
  count = 0;
  browser.runtime.sendMessage({
    type: "apiResponse",
    data: data,
  });
}
