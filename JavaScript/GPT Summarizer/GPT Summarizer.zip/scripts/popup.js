// popup.js

document.addEventListener("DOMContentLoaded", () => {
    console.log("----------\n");
	toggleButtonsVisibility();
    browser.runtime.sendMessage({
        type: "getTextContent"
    });
});


function toggleButtonsVisibility() {
	document.getElementById("buttons").style.display = (document.getElementById("buttons").style.display === "none" ? "flex" : "none");
}

function copyAll() {
	var results = document.getElementById("results").textContent;
	navigator.clipboard.writeText(results);
}

function refresh() {
	toggleButtonsVisibility();
	var foxElement = document.getElementById("fox");
	var resultsElement = document.getElementById("results");
	resultsElement.innerHTML = "";
	foxElement.style.display = "block";
	
	console.log("Refreshing\n----------\n");
    browser.runtime.sendMessage({
        type: "getTextContent"
    });
}

document.getElementById("refreshBtn").addEventListener("click", refresh);
document.getElementById("copyBtn").addEventListener("click", copyAll);

browser.runtime.onMessage.addListener(function (response) {
    if (response.type === 'apiResponse' && response.data) {
        // Handle the data received from background.js
        displayResponse(response.data);

    }
});

function formatResponse(formattedMessage) {
	// Convert text enclosed with "==" to h3 tags
	formattedMessage = formattedMessage.replace(/==(.+?)==/g, '<h3>$1</h3>');

	// Convert markdown bold (double asterisks) to HTML bold
	formattedMessage = formattedMessage.replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>');

	// Convert markdown bold (single asterisks) to HTML bold
	formattedMessage = formattedMessage.replace(/\*(?!\*)(.*?)\*(?!\*)/g, '<strong>$1</strong>');

	// Convert markdown italics to HTML italics
	formattedMessage = formattedMessage.replace(/_(.*?)_/g, '<em>$1</em>');

	// Replace lines that start with "-" and end with ":" with h4 tags
	formattedMessage = formattedMessage.replace(/-(.+?):/g, '<h4>$1:</h4>');

	// Convert lines that start with "*" into "  -"
	formattedMessage = formattedMessage.replace(/^\*\s*(.+)/gm, '-&nbsp;&nbsp;$1');

	// Replace newline characters with HTML line breaks last to maintain markup integrity
	formattedMessage = formattedMessage.replace(/\n/g, '<br>');
	
	return formattedMessage;
}


function displayResponse(data) {
 //   console.log("popup.js: Displaying data ", data);
	toggleButtonsVisibility();
	var textData = data.choices[0].message.content;
	
    if (data.choices) {
		document.getElementById("fox").style.display = "none";
        document.getElementById("results").innerHTML = formatResponse(textData);		
    } else {
        resultsElement.innerText = "No data available";
    }
}
